package com.company;

public abstract class Security {

    public abstract boolean login(String pinNumber);
}