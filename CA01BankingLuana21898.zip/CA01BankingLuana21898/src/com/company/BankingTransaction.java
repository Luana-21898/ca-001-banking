package com.company;

public class BankingTransaction {

    protected double amount;
    protected BankCustomer customer;
    protected int	typeAccount;
    protected String typeTransaction;



}
