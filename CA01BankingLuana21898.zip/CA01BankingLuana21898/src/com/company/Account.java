package com.company;

public class Account {

    protected String account;
}
