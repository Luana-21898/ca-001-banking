package com.company;

public class BankCustomer {

    String firstName;
    String lastName;
    String eMail;
    String customerAccount;
    String pin;

    CurrentAccount ca;
    SavingAccount sa;


    public BankCustomer(String _firstName, String _lastName, String _eMail) {
        firstName = _firstName;
        lastName = _lastName;
        eMail = _eMail;
        customerAccount = pinGenerator(false);
        pin = pinGenerator(true);

        ca = new CurrentAccount(customerAccount);
        sa = new SavingAccount(customerAccount);
    }


    private String pinGenerator(boolean _pin) {

        char[] alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};


        int firstLetter = 1, lastLetter = 1;


        System.out.println();
        for (int i = 0; i < alphabet.length; i++) {
            if (Character.toLowerCase(firstName.charAt(0)) == alphabet[i]) {
                firstLetter += i;
            }
            if (Character.toLowerCase(lastName.charAt(0)) == alphabet[i]) {
                lastLetter += i;
            }

        }

        if (!_pin) {
            return String.format("%c%c-%s-%02d-%02d", Character.toLowerCase(firstName.charAt(0)), Character.toLowerCase(lastName.charAt(0)),
                    (firstName.length() + lastName.length()), firstLetter, lastLetter);
        } else {
            return String.format("%02d%02d", firstLetter, lastLetter);
        }

    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    public CurrentAccount getCa() {
        return ca;
    }

    public void setCa(CurrentAccount ca) {
        this.ca = ca;
    }

    public SavingAccount getSa() {
        return sa;
    }

    public void setSa(SavingAccount sa) {
        this.sa = sa;
    }

    public boolean login(String pinNumber) {
        return false;
    }


}

