package com.company;

public class SecurityBanking extends Security {

    public boolean login(String employeePin) {

        if (employeePin.equals("A1234")) {
            return true;
        }

        return false;
    }
}
