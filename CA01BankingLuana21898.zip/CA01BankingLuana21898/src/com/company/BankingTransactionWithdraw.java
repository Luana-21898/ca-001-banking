package com.company;

public class BankingTransactionWithdraw extends BankingTransaction {


    public BankingTransactionWithdraw(BankCustomer c, double d, int _typeAccount)
    {
        customer = c;
        amount = d;
        typeAccount = _typeAccount;
        typeTransaction = "W";

    }



}
