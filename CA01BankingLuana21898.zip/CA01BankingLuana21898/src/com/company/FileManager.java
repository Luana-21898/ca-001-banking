package com.company;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Formatter;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class FileManager {

    private static Formatter output;
    private static Scanner input;

    private static String customerFile = "customerlisting.txt";


    public static boolean RemoveCustomerFromFile(BankCustomer c) {
        OpenFileToRead();

        if (c.ca.getBalance() != 0 || c.sa.getBalance() != 0) {
            System.err.println("The balance must have 0 value ");
            return false;
        }

        try {
            while (input.hasNext()) {
                String fn, ln, em, ac, pi;
                fn = input.next();
                ln = input.next();
                em = input.next();
                ac = input.next();
                pi = input.next();


                System.out.printf("%s %s %s %s %n", fn, ln, em, ac);

                if (ac.equals(c.getCustomerAccount())) {
                    input.remove();
                }

            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");
            return false;
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");
            return false;

        }

        CloseFile();

        return true;
    }

    public static void AddCustomerToFile(BankCustomer customer) {
        OpenFileToWrite(customerFile);
        output.format("%s %s %n", customer.firstName, customer.lastName);
        CloseFile();

    }

    public static void CreateCustomerAccount(String customerAccountName, int savingAccount) {
        OpenFileToWrite(customerAccountName);

        output.format("testing customer account %n");
        CloseFile();
    }

    public static BankCustomer getCustomer(String fName, String lName, String accountNumber, String pin) {
        OpenFileToRead();

        try {
            while (input.hasNext()) {

                String fn, ln, em, ac, pi;
                fn = input.next();
                ln = input.next();
                em = input.next();
                ac = input.next();
                pi = input.next();

                if (fName.equals(fn) && lName.equals(ln) && accountNumber.equals(ac) && pin.equals(pi)) {
                    return new BankCustomer(fn, ln, em);
                }

            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");

            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");

            System.exit(1);

        }

        CloseFile();
        return null;
    }

    public static BankCustomer getCustomer(String account) {
        OpenFileToRead();

        try {
            while (input.hasNext()) {
                String fName, lName, eMail, accountNumber;
                fName = input.next();
                lName = input.next();
                eMail = input.next();
                accountNumber = input.next();

                System.out.printf("%s %s %s %d %d%n", input.next(), input.next(), input.nextInt(), input.nextInt());

                if (account.equals(accountNumber)) {
                    return new BankCustomer(fName, lName, eMail);
                } else {
                    return null;
                }

            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");

            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");

            System.exit(1);

        }

        CloseFile();

        return null;
    }

    public static void ListOfCustomers() {

        OpenFileToRead();

        try {
            while (input.hasNext()) {
                System.out.printf("%s %s %d %d%n", input.next(), input.next(), input.nextInt(), input.nextInt());
                System.out.printf("%s %s %d %d%n", input.next(), input.next(), input.nextInt(), input.nextInt());
            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");
            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");
            System.exit(1);

        }

        CloseFile();

    }

    public static double total(String account, int _type) {

        String filename;
        double total = 0;

        if (_type == AppConstants.SAVING_ACCOUNT)
            filename = account + "-savings.txt";
        else
            filename = account + "-current.txt";

        if (hasFile(filename))
            OpenFileToRead(filename);
        else
            return total;


        try {
            while (input.hasNext()) {

                String date, transaction;
                double amount, balance;
                date = input.next();
                transaction = input.next();
                amount = input.nextDouble();
                balance = input.nextDouble();

                total += amount;


            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");

            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");

            System.exit(1);

        }

        CloseFile();

        return total;
    }

    public static void ListOfCustomersBalance() {

        OpenFileToRead();

        try {
            while (input.hasNext()) {
                String fName, lName, eMail, accountNumber, pin;
                fName = input.next();
                lName = input.next();
                eMail = input.next();
                accountNumber = input.next();
                pin = input.next();

                double current = total(accountNumber, AppConstants.CURRENT_ACCOUNT);
                double saving = total(accountNumber, AppConstants.SAVING_ACCOUNT);

                System.out.printf("%s %s %s %s current: %f savings: %f %n", fName, lName, eMail, accountNumber, current, saving);
            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");
            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");
            System.exit(1);

        }

        CloseFile();

    }

    private static void OpenFileToWrite(String fileToOpen) {

        try {
            FileWriter f = new FileWriter(fileToOpen, true);
            output = new Formatter(f);
        } catch (SecurityException securityException) {
            System.out.println("Write permission denied");
            System.exit(1);
        } catch (FileNotFoundException fileNotFoundException) {
            System.out.println("Error opening file, Terminating");
            System.exit(1);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }

    }

    private static void CloseFile() {

        if (output != null) {
            output.close();
        }
    }

    private static void OpenFileToRead() {

        try {
            input = new Scanner(Paths.get(customerFile));
        } catch (IOException ioException) {
            System.err.println("Error opening file. Terminating");
            System.exit(1);
        }

    }

    private static void OpenFileToRead(String file) {

        try {
            input = new Scanner(Paths.get(file));
        } catch (IOException ioException) {
            System.err.println("Error opening " + file + ". Terminating");
            System.exit(1);
        }

    }

    public static String date() {

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date(System.currentTimeMillis());

        return formatter.format(date);
    }

    public static void AddTransactionToFile(BankingTransaction transaction) {

        if (transaction.typeAccount == AppConstants.CURRENT_ACCOUNT) {
            OpenFileToWrite(transaction.customer.getCustomerAccount() + "-current.txt");

            if (!transaction.customer.getCa().setBalance(transaction.typeTransaction, transaction.amount)) {
                System.out.println("Negative balance is not allowed.");
                CloseFile();
                return;
            }

            output.format("%s %s %f %f %n", date(), transaction.typeTransaction, transaction.amount, transaction.customer.getCa().getBalance());
        } else {
            OpenFileToWrite(transaction.customer.getCustomerAccount() + "-savings.txt");

            if (!transaction.customer.getSa().setBalance(transaction.typeTransaction, transaction.amount)) {
                System.out.println("Negative balance are is allowed.");
                CloseFile();
                return;
            }

            output.format("%s %s %f %f %n", date(), transaction.typeTransaction, transaction.amount, transaction.customer.getSa().getBalance());
        }

        CloseFile();

    }

    private static boolean hasFile(String name) {
        try {
            input = new Scanner(Paths.get(name));
            return true;
        } catch (IOException ioException) {
            System.err.println("Error opening " + name + ".");
            return false;
        }
    }

    public static boolean hasCustomer(String _fName, String _lName, String _account, String _pin) {

        OpenFileToRead();

        try {
            while (input.hasNext()) {
                String fName, lName, eMail, accountNumber, pin;
                fName = input.next();
                lName = input.next();
                eMail = input.next();
                accountNumber = input.next();
                pin = input.next();

                if (_fName.equals(fName) && _lName.equals(lName) && _account.equals(accountNumber) && _pin.equals(pin)) {
                    return true;
                }

            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");

            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");

            System.exit(1);

        }

        CloseFile();

        return false;
    }

    public static void ListOfTransactions(String account, int type) {

        String filename;

        if (type == AppConstants.SAVING_ACCOUNT)
            filename = account + "-savings.txt";
        else
            filename = account + "-current.txt";

        if (hasFile(filename))
            OpenFileToRead(filename);


        try {
            while (input.hasNext()) {

                String date, transaction;
                double amount, balance;
                date = input.next();
                transaction = input.next();
                amount = input.nextDouble();
                balance = input.nextDouble();

                System.out.printf("%s %s %f %f %n", date, (transaction.equals("L")) ? "Lodge" : "Withdraw", amount, balance);

            }
        } catch (NoSuchElementException elementException) {
            System.err.println("File improperly formed. Terminating");

            System.exit(1);
        } catch (IllegalStateException stateException) {
            System.err.println("Error reading from file. Terminating");

            System.exit(1);

        }

        CloseFile();


    }
}

