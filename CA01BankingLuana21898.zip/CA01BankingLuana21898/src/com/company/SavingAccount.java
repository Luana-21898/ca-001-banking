package com.company;

public class SavingAccount extends Account {

    private double balance;


    public SavingAccount(String account)
    {
        this.account = account;
        FileManager.CreateCustomerAccount(account, AppConstants.SAVING_ACCOUNT);
        balance = FileManager.total(account, AppConstants.SAVING_ACCOUNT );
    }



    public double getBalance() {
        return balance;
    }

    public boolean setBalance(String type, double balance) {


        double newBalance = this.balance;

        if(type.equals("Lodge")) {
            newBalance += balance;
        } else {
            newBalance -= balance;
        }
        if(newBalance < 0) {
            return false;
        }

        this.balance = newBalance;

        return true;

    }


}
