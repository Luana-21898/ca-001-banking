package com.company;

import java.util.Formatter;
import java.util.Scanner;

public class BankingAction {

    public static void addCustomer(BankCustomer customer) {

        System.out.println("Creating " + customer.firstName + " " + customer.lastName );
    }

    public static void deleteCustomer() {

    }

    public static void createTransaction(BankingTransaction transaction) {

        System.out.println("Creating Transaction...");

        if (transaction.customer != null)
        {
            System.out.println(" value: "+ transaction.amount + " account: " + transaction.customer.getCustomerAccount() +
                    " type: " + transaction.typeTransaction);

            FileManager.AddTransactionToFile(transaction);
        }

    }

    public static void ListOfCustomers()
    {
        FileManager.ListOfCustomers();
    }

    public static void listCustomersBalance()
    {
        FileManager.ListOfCustomersBalance();
    }

    public static void listOfTransactionHistory(String account, int type){
        FileManager.ListOfTransactions(account, type);
    }
}