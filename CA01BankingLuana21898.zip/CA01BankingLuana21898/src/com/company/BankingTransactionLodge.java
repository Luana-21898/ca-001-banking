package com.company;

public class BankingTransactionLodge extends BankingTransaction
{
    public BankingTransactionLodge(BankCustomer c, double d, int _typeAccount)
    {
        customer = c;
        amount = d;
        typeAccount = _typeAccount;
        typeTransaction = "L";
    }


}


